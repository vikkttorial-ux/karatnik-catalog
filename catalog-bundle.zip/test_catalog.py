"""Проверки критичных правил на вымышленных строках, без реальных секретов."""
import copy
import json
from pathlib import Path
import tempfile
import unittest

from catalog import (BuildError, ROOT, analyze, normalize_size, photo_filename,
                     resolve_headers, save_catalog, scan_site, validate_catalog)

CONFIG = json.loads((ROOT / 'config.json').read_text(encoding='utf-8'))
CONFIG['stone_rules_approved'] = True
CONFIG['missing_article_policy'] = 'error'
CONFIG['ignore_empty_code_templates'] = False
HEADER = list(CONFIG['headers'].values())


def source(*entries):
    rows = []
    for n, entry in enumerate(entries):
        defaults = dict(art='01-2169', tip='Кольцо', proba='585', cvet='Б',
                        size='17', code=f'КОД-{n}', stock='Ленинградка', naim='Кольцо без вставки')
        defaults.update(entry)
        rows.append([defaults.get(key, '') for key in CONFIG['headers']])
    return [HEADER, *rows]


class CatalogTests(unittest.TestCase):
    def build(self, *entries):
        return analyze(source(*entries), CONFIG)

    def test_duplicate_header_first_and_moved_columns(self):
        values = source({})
        values[0] = values[0] + ['Проба', 'Наименование изделя']
        values[1] += ['999', 'Чужой тип']
        data, _ = analyze(values, CONFIG)
        self.assertEqual(data['items'][0]['proba'], '585')
        self.assertEqual(data['items'][0]['tip'], 'Кольцо')
        swapped = [row[::-1] for row in source({})]
        self.assertEqual(analyze(swapped, CONFIG)[0]['items'][0]['proba'], '585')

    def test_missing_size_header_fails(self):
        header = HEADER.copy()
        header[header.index('Размер')] = 'Размер переименован'
        with self.assertRaisesRegex(BuildError, 'Размер'):
            resolve_headers(header, CONFIG)

    def test_sales_returns_not_inventory_and_sizes_sorted(self):
        data, report = self.build({'size':'17_5'}, {'size':'16'}, {'size':'17,50'}, {'service':'продажа'}, {'service':'возврат'})
        item = data['items'][0]
        self.assertEqual(item['units'], 3)
        self.assertEqual(item['sizes'], [{'s':'16','q':1}, {'s':'17,5','q':2}])
        self.assertEqual(item['stocks'], {'Ленинградская 33':3})
        validate_catalog(data, report['inventory_rows'])

    def test_modal_value_ignores_blanks_and_tie_uses_first(self):
        data, report = self.build({'proba':'925','tip':''}, {'proba':'585'}, {'proba':'585','tip':''}, {'proba':''})
        self.assertEqual(data['items'][0]['proba'], '585')
        self.assertEqual(data['items'][0]['tip'], 'Кольцо')
        self.assertEqual(report['characteristic_conflicts'], 1)
        self.assertEqual(self.build({'proba':'925'}, {'proba':'585'})[0]['items'][0]['proba'], '925')

    def test_article_case_and_leading_zeros_preserved(self):
        data, report = self.build({'art':' 01-2169 '}, {'art':'к-1'}, {'art':'К-1'})
        self.assertEqual({i['art'] for i in data['items']}, {'01-2169','к-1','К-1'})
        self.assertEqual(report['articles_with_id'],3)

    def test_missing_article_blocks_and_does_not_overwrite(self):
        data, report = self.build({}, {'art':''})
        self.assertEqual(report['inventory_rows'], 2)
        self.assertEqual(report['units_with_id'], 1)
        with tempfile.TemporaryDirectory() as folder:
            p = Path(folder) / 'data.json'
            p.write_text('Предыдущий каталог', encoding='utf-8')
            with self.assertRaises(BuildError):
                save_catalog(data, report, p)
            self.assertEqual(p.read_text(encoding='utf-8'), 'Предыдущий каталог')

    def test_formula_size_logged_not_guessed(self):
        data, report = self.build({'size':'#N/A','naim':'Кольцо размер 17,5 без вставки'})
        self.assertEqual(data['items'][0]['sizes'], [])
        self.assertEqual(report['issue_counts']['ОШИБКА ФОРМУЛЫ'],1)

    def test_formula_in_status_is_fatal(self):
        _, report = self.build({'service':'#N/A'})
        self.assertTrue(any('ошибка формулы' in b for b in report['blockers']))

    def test_unknown_stock_and_empty_stock_preserved(self):
        data, report = self.build({'stock':'Новый склад'}, {'stock':''}, {'stock':'Гостиный двор'})
        self.assertEqual(data['items'][0]['stocks'], {'Новый склад':1,'Склад не указан':1,'Гостинка (В.Е.Левин)':1})
        self.assertEqual(report['issue_counts']['НОВЫЙ СКЛАД'],1)

    def test_approved_stock_alias(self):
        data,_=self.build({'stock':'гостика'})
        self.assertEqual(data['items'][0]['stocks'], {'Гостинка (В.Е.Левин)':1})

    def test_drop_guard_boundary(self):
        previous = {'items':[{}] * 20}
        data, report = self.build(*[{'art':f'А-{n}'} for n in range(17)])
        validate_catalog(data,17,previous)
        data['items'].pop()
        with self.assertRaisesRegex(BuildError,'снизилось'):
            validate_catalog(data,16,previous)

    def test_stock_sum_and_source_sum(self):
        data,_=self.build({})
        with self.assertRaises(BuildError):
            validate_catalog(data,2)
        data['items'][0]['stocks']['Ленинградская 33'] = 2
        with self.assertRaisesRegex(BuildError,'складам'):
            validate_catalog(data,1)

    def test_forbidden_fields_and_text(self):
        for field in ['цена','себестоимость','маржа','наценка','закупка','price','cost']:
            data,_=self.build({})
            data['items'][0][field]=1
            with self.subTest(field=field), self.assertRaises(BuildError):
                validate_catalog(data,1)
        data,_=self.build({'naim':'Изделие, цена 100'})
        with self.assertRaises(BuildError):
            validate_catalog(data,1)

    def test_html_entities_and_json_unicode_escapes(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'index.html'
            p.write_text('&#1094;&#1077;&#1085;&#1072;',encoding='utf-8')
            with self.assertRaises(BuildError):
                scan_site(folder)
            p.unlink()
            (Path(folder)/'data.json').write_text(json.dumps({'цена':1}),encoding='utf-8')
            with self.assertRaises(BuildError):
                scan_site(folder)

    def test_css_layout_property_is_not_financial_data(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'styles.css'
            p.write_text('body{margin:0;margin-top:10px}',encoding='utf-8')
            scan_site(folder)
            p.write_text('body{margin:0;content:"маржа"}',encoding='utf-8')
            with self.assertRaises(BuildError):
                scan_site(folder)

    def test_unapproved_rules_block_build(self):
        config=copy.deepcopy(CONFIG)
        config['stone_rules_approved']=False
        _, report=analyze(source({}),config)
        self.assertTrue(report['blockers'])

    def test_stones_unknown_not_bare_and_brand_not_stone(self):
        self.assertEqual(self.build({'naim':'Кольцо','full_name':'','vstavka':''})[0]['items'][0]['kamni'],'Не определено')
        self.assertEqual(self.build({'marka':'Янтарная волна','naim':'Кольцо БР-Янтарная_волна','full_name':''})[0]['items'][0]['kamni'],'Не определено')
        self.assertEqual(self.build({'naim':'Кольцо Ф.20'})[0]['items'][0]['kamni'],'Фианитовая группа')
        self.assertEqual(self.build({'naim':'Кольцо','vstavka':'2 Бриллиант и 1 Топаз'})[0]['items'][0]['kamni'],'Бриллиантовая группа')

    def test_source_financial_cells_never_projected(self):
        v=source({})
        v[0]=v[0]+['Цена со скидкой','ФИО продавца']
        v[1]=v[1]+['123456789','Частное имя']
        data,_=analyze(v,CONFIG)
        serialized=json.dumps(data,ensure_ascii=False)
        self.assertNotIn('123456789',serialized)
        self.assertNotIn('Частное имя',serialized)

    def test_template_rows_not_silently_discarded(self):
        values=source({})
        template=['']*len(HEADER)
        template[HEADER.index('Код')]='ЮР-000'
        values.append(template)
        _,report=analyze(values,CONFIG)
        self.assertEqual(report['inventory_rows_without_article'],1)

    def test_approved_template_exception_and_missing_article_kept(self):
        config=copy.deepcopy(CONFIG)
        config.update(ignore_empty_code_templates=True,missing_article_policy='unit_code')
        values=source({}, {'art':'','code':'ЮР-12345678'})
        template=['']*len(HEADER)
        template[HEADER.index('Код')]='ЮР-000'
        values.append(template)
        data,report=analyze(values,config)
        self.assertEqual(report['ignored_templates'],1)
        self.assertEqual(report['inventory_rows'],2)
        self.assertEqual(report['technical_cards'],1)
        self.assertEqual(report['articles_with_id'],1)
        self.assertIn('Без артикула · ЮР-12345678',[i['art'] for i in data['items']])
        self.assertEqual(report['blockers'],[])
        validate_catalog(data,2)
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'data.json'
            save_catalog(data,report,p)
            self.assertEqual(json.loads(p.read_text(encoding='utf-8')),data)

    def test_template_with_product_fields_is_not_excluded(self):
        config=copy.deepcopy(CONFIG)
        config.update(ignore_empty_code_templates=True,missing_article_policy='unit_code')
        data,report=analyze(source({'art':'','code':'ЮР-000','naim':'Цепь'}),config)
        self.assertEqual(report['ignored_templates'],0)
        self.assertEqual(report['catalog_units'],1)

    def test_technical_key_collision_is_blocked(self):
        config=copy.deepcopy(CONFIG)
        config['missing_article_policy']='unit_code'
        _,report=analyze(source({'art':'','code':'ЮР-1'},{'art':'','code':'ЮР-1'}),config)
        self.assertTrue(report['blockers'])
        _,report=analyze(source({'art':'','code':'ЮР-1'},{'art':'Без артикула · ЮР-1'}),config)
        self.assertTrue(report['blockers'])

    def test_filename_safe_and_collision_free_for_percent(self):
        self.assertEqual(photo_filename('К-3463-Р'),'К-3463-Р.webp')
        self.assertEqual(photo_filename('ЗК1020/Изм'),'ЗК1020%2FИзм.webp')
        self.assertNotEqual(photo_filename('А/Б'),photo_filename('А%2FБ'))
        self.assertEqual(photo_filename('CON'),'%43ON.webp')

    def test_unknown_type_remains_visible(self):
        self.assertEqual(self.build({'tip':''})[0]['items'][0]['tip'],'Не определено')
        self.assertEqual(self.build({'tip':'Пдкввеска'})[0]['items'][0]['tip'],'Пдкввеска')


if __name__ == '__main__':
    unittest.main(verbosity=2)
