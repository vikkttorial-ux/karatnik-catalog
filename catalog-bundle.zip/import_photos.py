"""Импорт встроенных фото XLSX по точному артикулу и бренду, без изменения источника."""
import argparse
from collections import defaultdict
from io import BytesIO
import json
from pathlib import Path
import posixpath
import struct
from urllib.parse import quote
import xml.etree.ElementTree as ET
import zipfile
import zlib

from PIL import Image, ImageOps
from catalog import photo_filename, scan_site

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main',
      'd': 'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing',
      'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
      'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
RID = '{' + NS['r'] + '}'


def archive_entries(path, allow_partial=False):
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            return {name: archive.read(name) for name in archive.namelist()
                    if name.startswith('xl/')}, False
    if not allow_partial:
        raise ValueError('XLSX скачан не полностью. Для восстановления целых записей нужен --allow-partial.')
    source = Path(path).read_bytes()
    view = memoryview(source)
    result, offset = {}, 0
    while source[offset:offset + 4] == b'PK\x03\x04':
        if offset + 30 > len(source):
            break
        _, _, flags, method, _, _, crc, size, _, name_len, extra_len = struct.unpack_from('<IHHHHHIIIHH', source, offset)
        name = source[offset + 30:offset + 30 + name_len].decode('utf-8')
        start = offset + 30 + name_len + extra_len
        if flags & 1 or method not in (0, 8):
            raise ValueError('Неподдерживаемая запись ZIP')
        if flags & 8:
            if method != 8:
                raise ValueError('Неподдерживаемый поток ZIP')
            decoder = zlib.decompressobj(-15)
            data = decoder.decompress(view[start:])
            if not decoder.eof:
                break
            end = len(source) - len(decoder.unused_data)
            descriptor = end + (4 if source[end:end + 4] == b'PK\x07\x08' else 0)
            if descriptor + 12 > len(source):
                break
            crc, compressed, uncompressed = struct.unpack_from('<III', source, descriptor)
            if compressed != end - start or uncompressed != len(data):
                raise ValueError('Размеры записи ZIP не совпадают')
            offset = descriptor + 12
        else:
            end = start + size
            if end > len(source):
                break
            data = zlib.decompress(view[start:end], -15) if method == 8 else bytes(view[start:end])
            offset = end
        if zlib.crc32(data) & 0xffffffff != crc:
            raise ValueError('Контрольная сумма ZIP не совпадает: ' + name)
        if name.startswith('xl/'):
            result[name] = data
    return result, True


def relationships(entries, part):
    relpath = posixpath.join(posixpath.dirname(part), '_rels', posixpath.basename(part) + '.rels')
    return {r.get('Id'): posixpath.normpath(posixpath.join(posixpath.dirname(part), r.get('Target')))
            for r in ET.fromstring(entries[relpath]) if r.get('TargetMode') != 'External'}


def photo_rows(entries):
    workbook = 'xl/workbook.xml'
    sheets = ET.fromstring(entries[workbook]).findall('m:sheets/m:sheet', NS)
    sheet = next(s for s in sheets if s.get('name') == 'Ассортимент')
    part = relationships(entries, workbook)[sheet.get(RID + 'id')]
    shared = [''.join(s.itertext()) for s in ET.fromstring(entries['xl/sharedStrings.xml'])]
    sheetxml = ET.fromstring(entries[part])
    rows = {}
    for row in sheetxml.findall('m:sheetData/m:row', NS):
        values = {}
        for cell in row:
            col = ''.join(c for c in cell.get('r', '') if c.isalpha())
            if col not in ('B', 'C', 'L'):
                continue
            val = cell.find('m:v', NS)
            text = val.text if val is not None else ''
            if cell.get('t') == 's' and text:
                text = shared[int(text)]
            elif cell.get('t') == 'inlineStr':
                text = ''.join(cell.find('m:is', NS).itertext())
            values[col] = (text or '').strip()
        rows[int(row.get('r'))] = values
    if any(rows.get(2, {}).get(col) != label for col, label in [('B', 'Артикул'), ('C', 'Фото'), ('L', 'Бренд')]):
        raise ValueError('Изменились заголовки Артикул / Фото / Бренд листа Ассортимент')
    drawing = sheetxml.find('m:drawing', NS)
    drawingpart = relationships(entries, part)[drawing.get(RID + 'id')]
    rels = relationships(entries, drawingpart)
    for anchor in ET.fromstring(entries[drawingpart]):
        origin, blip = anchor.find('d:from', NS), anchor.find('.//a:blip', NS)
        if origin is None or blip is None or origin.findtext('d:col', namespaces=NS) != '2':
            continue
        rownum = int(origin.findtext('d:row', namespaces=NS)) + 1
        row = rows.get(rownum, {})
        yield rownum, row.get('B', ''), row.get('L', ''), rels.get(blip.get(RID + 'embed'), '')


def webp_image(raw):
    with Image.open(BytesIO(raw)) as source:
        source.load()
        foreground = ImageOps.exif_transpose(source).convert('RGBA')
        background = Image.new('RGBA', foreground.size, 'white')
        image = Image.alpha_composite(background, foreground).convert('RGB')
        image.thumbnail((480, 480), Image.Resampling.LANCZOS)
        # Полотно сохраняет пропорции и не обрезает изделие.
        canvas = Image.new('RGB', (480, 480), 'white')
        canvas.paste(image, ((480 - image.width) // 2, (480 - image.height) // 2))
        for quality in (80, 75, 65, 55, 40):
            stream = BytesIO()
            canvas.save(stream, format='WEBP', quality=quality, method=6)
            if stream.tell() <= 60000:
                return stream.getvalue()
    raise ValueError('Не удалось сжать фото до 60 КБ')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('xlsx')
    parser.add_argument('--site', default='site')
    parser.add_argument('--report', default='reports/photos.json')
    parser.add_argument('--allow-partial', action='store_true')
    args = parser.parse_args()
    entries, partial = archive_entries(args.xlsx, args.allow_partial)
    site = Path(args.site)
    data = json.loads((site / 'data.json').read_text(encoding='utf-8'))
    items = {item['art']: item for item in data['items']}
    candidates = defaultdict(list)
    missing, mismatch = 0, []
    for row, art, brand, media in photo_rows(entries):
        if art not in items:
            continue
        if not brand or brand.casefold() != items[art]['marka'].strip().casefold():
            mismatch.append({'row': row, 'art': art, 'source_brand': brand, 'catalog_brand': items[art]['marka']})
            continue
        if media not in entries:
            missing += 1
            continue
        candidates[art].append((row, media))
    (site / 'photos').mkdir(exist_ok=True)
    imported, failed, duplicates = [], [], []
    for art, choices in sorted(candidates.items()):
        # При нескольких фото берётся первая строка с тем же артикулом и брендом.
        if len(choices) > 1:
            duplicates.append({'art': art, 'rows': [x[0] for x in choices]})
        row, media = min(choices)
        try:
            image = webp_image(entries[media])
        except (OSError, ValueError) as error:
            failed.append({'art': art, 'reason': str(error)})
            continue
        filename = photo_filename(art)
        (site / 'photos' / filename).write_bytes(image)
        items[art]['photo'] = 'photos/' + quote(filename, safe='-_.')
        imported.append({'art': art, 'row': row, 'media': media, 'bytes': len(image)})
    # Дата остатков не меняется при добавлении фото.
    temporary = site / 'data.tmp'
    temporary.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':')), encoding='utf-8')
    temporary.replace(site / 'data.json')
    report = {'source_sheet': 'Ассортимент', 'partial_archive': partial, 'imported': len(imported),
              'cards': len(items), 'without_photo': sum(not i['photo'] for i in items.values()),
              'missing_image_rows': missing, 'brand_mismatches': mismatch,
              'duplicate_articles': duplicates, 'errors': failed, 'images': imported}
    target = Path(args.report)
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    scan_site(site)
    print(json.dumps({k: report[k] for k in ('partial_archive', 'imported', 'cards', 'without_photo')}, ensure_ascii=False))


if __name__ == '__main__':
    main()
